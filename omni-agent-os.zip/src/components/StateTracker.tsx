import { Share2, Database, Filter, MemoryStick, PersonStanding, X, Copy, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function StateTracker() {
  return (
    <div className="h-full flex relative overflow-hidden bg-grid">
      {/* Telemetry Panel */}
      <div className="absolute top-6 left-6 z-20 glass-panel rounded-md p-4 w-72">
        <h3 className="font-display font-bold text-sm text-primary uppercase tracking-widest mb-4 flex items-center gap-2">
          <ActivityIcon /> Live Telemetry
        </h3>
        <div className="space-y-4 font-mono text-sm">
          {[
            { label: 'Sys_Latency', value: '420ms', color: 'text-secondary' },
            { label: 'Generation_Rate', value: '64 T/s', color: 'text-primary' },
            { label: 'Vector_Dim', value: '1536', color: 'text-purple' },
            { label: 'Active_Nodes', value: '4/4', color: 'text-slate-200' },
          ].map((stat) => (
            <div key={stat.label} className="flex justify-between items-end border-b border-primary/10 pb-1">
              <span className="text-slate-500 text-xs">{stat.label}</span>
              <span className={`${stat.color} ${stat.color === 'text-secondary' ? 'glow-primary' : ''}`}>{stat.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Isometric Visualization */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="relative w-[800px] h-[600px] perspective-[1000px]">
          <svg className="absolute inset-0 w-full h-full overflow-visible pointer-events-none">
            <path d="M 150 300 L 350 150" fill="none" stroke="rgba(0, 229, 255, 0.2)" strokeWidth="2" />
            <path className="animate-flow" d="M 150 300 L 350 150" fill="none" stroke="#00E5FF" strokeWidth="2" />
            
            <path d="M 350 150 L 550 300" fill="none" stroke="rgba(0, 229, 255, 0.2)" strokeWidth="2" />
            <path className="animate-flow" d="M 350 150 L 550 300" fill="none" stroke="#00E5FF" strokeWidth="2" style={{ animationDelay: '0.5s' }} />
            
            <path d="M 550 300 L 750 150" fill="none" stroke="rgba(176, 38, 255, 0.2)" strokeWidth="2" />
            <path className="animate-flow" d="M 550 300 L 750 150" fill="none" stroke="#B026FF" strokeWidth="2" style={{ animationDelay: '1s' }} />
          </svg>

          {/* Nodes */}
          <Node x={110} y={260} icon={PersonStanding} label="USER_INPUT" color="primary" id="0" />
          <Node x={310} y={110} icon={Database} label="VECTOR_DB" color="primary" id="1" />
          <Node x={510} y={260} icon={Filter} label="RERANKER" color="primary" id="2" />
          <Node x={710} y={110} icon={MemoryStick} label="LLM_GENERATOR" color="purple" id="3" isLarge />
        </div>
      </div>

      {/* Payload Inspector */}
      <div className="w-96 glass-panel border-l border-primary/20 flex flex-col z-30 h-full">
        <div className="p-6 border-b border-primary/15 flex justify-between items-center bg-black/40">
          <div className="flex items-center gap-2">
            <Share2 size={18} className="text-primary" />
            <h3 className="font-display font-bold text-lg text-white tracking-wide uppercase">Payload Inspector</h3>
          </div>
          <button className="text-slate-500 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 flex-1 flex flex-col gap-6 overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'SOURCE_NODE', value: 'Vector Retrieval', color: 'text-primary' },
              { label: 'TARGET_NODE', value: 'Context Assembly', color: 'text-purple' },
              { label: 'PAYLOAD_SIZE', value: '1.2 KB', color: 'text-white' },
              { label: 'STATUS', value: '200 OK', color: 'text-secondary' },
            ].map((meta) => (
              <div key={meta.label} className="flex flex-col gap-1 border border-primary/15 bg-black/40 p-3 rounded-md">
                <p className="text-slate-500 text-[10px] font-mono uppercase">{meta.label}</p>
                <p className={`${meta.color} text-xs font-mono truncate`}>{meta.value}</p>
              </div>
            ))}
          </div>

          <div className="flex-1 flex flex-col border border-primary/15 rounded-md overflow-hidden bg-black">
            <div className="bg-slate-900/80 border-b border-primary/15 px-3 py-2 flex justify-between items-center">
              <span className="text-xs font-mono text-slate-500">raw_data.json</span>
              <button className="text-slate-500 hover:text-primary transition-colors">
                <Copy size={14} />
              </button>
            </div>
            <div className="p-4 overflow-auto flex-1 text-xs font-mono leading-relaxed text-slate-300">
              <pre>{JSON.stringify({
                query_id: "req_9a8b7c6d",
                timestamp: 1715843201.45,
                action: "retrieve_chunks",
                parameters: {
                  top_k: 5,
                  similarity_threshold: 0.85,
                  namespace: "technical_docs"
                },
                results: [
                  { chunk_id: "chk_001", score: 0.92, preview: "The main console..." },
                  { chunk_id: "chk_042", score: 0.89, preview: "Hologram state..." }
                ]
              }, null, 2)}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Node({ x, y, icon: Icon, label, color, id, isLarge }: any) {
  return (
    <div 
      className="absolute z-10 group cursor-pointer"
      style={{ left: x, top: y }}
    >
      <div className={`w-${isLarge ? '24' : '20'} h-${isLarge ? '24' : '20'} transform rotate-45 glass-panel flex items-center justify-center bg-black/80 transition-all group-hover:shadow-[0_0_20px_rgba(0,229,255,0.4)] ${color === 'primary' ? 'border-primary' : 'border-purple shadow-[0_0_12px_rgba(176,38,255,0.3)]'}`}>
        <div className="transform -rotate-45 flex flex-col items-center">
          <Icon size={isLarge ? 32 : 24} className={color === 'primary' ? 'text-primary' : 'text-purple'} />
        </div>
      </div>
      <div className="absolute top-28 left-1/2 -translate-x-1/2 text-center w-40">
        <p className={`font-mono text-xs ${color === 'primary' ? 'text-primary' : 'text-purple font-bold'}`}>[{id}] {label}</p>
        {isLarge && <p className="font-mono text-[10px] text-slate-500">STREAMING...</p>}
      </div>
    </div>
  );
}

function ActivityIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </svg>
  );
}
