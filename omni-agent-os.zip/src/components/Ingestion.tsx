import { CloudUpload, Database, Terminal, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { PipelineItem } from '../types';
import { motion } from 'motion/react';

const PIPELINE_DATA: PipelineItem[] = [
  { id: '1', name: 'CORE_PROTOCOL_ALPHA.PDF', chunks: '1,248', tokens: '842.1K', vectors: '1,248', status: 'synced', progress: 100 },
  { id: '2', name: 'NEURAL_NET_SPECS_V2.MD', chunks: '421', tokens: '128.5K', vectors: '380', status: 'vectorizing', progress: 78 },
  { id: '3', name: 'USER_BEHAVIOR_LOGS.JSON', chunks: '8,902', tokens: '1.2M', vectors: '0', status: 'queued', progress: 5 },
  { id: '4', name: 'FINANCIAL_PROJECTIONS.XLSX', chunks: '--', tokens: '--', vectors: '--', status: 'error', progress: 0 },
];

const LOGS = [
  { type: 'info', content: 'Initializing ingestion matrix...' },
  { type: 'info', content: 'Connection established with Pinecone Cluster-01' },
  { type: 'proc', content: 'Sharding NEURAL_NET_SPECS_V2.MD...' },
  { type: 'proc', content: 'Chunking sequence 1-42 complete.' },
  { type: 'info', content: 'Chunk 42 embedded. Vector dim: 1536' },
  { type: 'info', content: 'Chunk 43 embedded. Vector dim: 1536' },
  { type: 'warn', content: 'Rate limit approaching on OpenAI API. Throttling...' },
  { type: 'proc', content: 'Upserting vectors to namespace: "production-v4"' },
  { type: 'info', content: 'Chunk 44 embedded. Vector dim: 1536' },
  { type: 'info', content: 'Chunk 45 embedded. Vector dim: 1536' },
  { type: 'info', content: 'Chunk 46 embedded. Vector dim: 1536' },
  { type: 'proc', content: 'Validation hash match for chunk 46: 0x8F2A...' },
  { type: 'info', content: 'System stabilizing', active: true },
];

export default function Ingestion() {
  return (
    <div className="h-full flex flex-col p-6 gap-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent pointer-events-none" />
      
      {/* Dropzone */}
      <section className="h-[35%] shrink-0">
        <div className="h-full glass-panel border-dashed border-2 border-primary/40 relative group cursor-pointer flex flex-col items-center justify-center transition-all hover:border-secondary hover:bg-secondary/5">
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary" />
          
          <div className="flex flex-col items-center text-center">
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              className="mb-4 text-primary"
            >
              <CloudUpload size={48} className="drop-shadow-[0_0_10px_rgba(0,229,255,0.5)]" />
            </motion.div>
            <h1 className="font-headline font-bold text-3xl text-slate-100 tracking-tighter uppercase">Initialize Knowledge Upload</h1>
            <p className="font-mono text-xs text-primary/60 mt-2 tracking-widest uppercase">Drag_and_Drop_Raw_Data_for_Neural_Mapping</p>
          </div>

          <div className="absolute bottom-4 right-6 flex gap-4">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Supported: PDF, MD, TXT, JSON</div>
            <div className="text-[10px] font-mono text-primary uppercase">Max Vol: 512MB</div>
          </div>
        </div>
      </section>

      {/* Split View */}
      <section className="flex-1 min-h-0 grid grid-cols-12 gap-6 pb-4">
        {/* Pipeline Table */}
        <div className="col-span-8 flex flex-col glass-panel overflow-hidden">
          <div className="bg-slate-900/80 px-6 py-3 border-b border-primary/10 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-secondary animate-pulse rounded-full" />
              <h3 className="font-headline text-xs font-bold tracking-widest uppercase text-slate-200">Active_Pipeline_Monitor</h3>
            </div>
            <div className="flex gap-4">
              <span className="font-mono text-[10px] text-slate-500 uppercase">Nodes: 128</span>
              <span className="font-mono text-[10px] text-secondary uppercase">Latency: 14ms</span>
            </div>
          </div>
          
          <div className="flex-1 overflow-auto">
            <table className="w-full text-left font-mono text-[11px]">
              <thead className="sticky top-0 bg-slate-900/95 backdrop-blur text-primary/70 border-b border-primary/10 uppercase tracking-tighter">
                <tr>
                  <th className="px-6 py-4 font-medium">Source_Asset</th>
                  <th className="px-4 py-4 font-medium">Chunks</th>
                  <th className="px-4 py-4 font-medium">Tokens</th>
                  <th className="px-4 py-4 font-medium">Vectors</th>
                  <th className="px-6 py-4 font-medium">Status_Matrix</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-primary/5">
                {PIPELINE_DATA.map((item) => (
                  <tr key={item.id} className="hover:bg-primary/5 transition-colors group">
                    <td className="px-6 py-4 text-slate-200 font-medium flex items-center gap-2">
                      <Database size={14} className="text-primary" />
                      {item.name}
                    </td>
                    <td className="px-4 py-4 text-slate-400">{item.chunks}</td>
                    <td className="px-4 py-4 text-slate-400">{item.tokens}</td>
                    <td className="px-4 py-4 text-slate-400">{item.vectors}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-1 bg-slate-800 overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${item.progress}%` }}
                            className={`h-full ${item.status === 'error' ? 'bg-error' : 'bg-secondary shadow-[0_0_8px_#00ffa3]'}`}
                          />
                        </div>
                        <span className={`text-[9px] uppercase font-bold ${
                          item.status === 'synced' ? 'text-secondary' :
                          item.status === 'vectorizing' ? 'text-primary animate-pulse' :
                          item.status === 'error' ? 'text-error' : 'text-slate-500'
                        }`}>
                          {item.status === 'error' && <AlertTriangle size={10} className="inline mr-1" />}
                          {item.status}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Logs */}
        <div className="col-span-4 flex flex-col glass-panel bg-black/40 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-secondary/30 to-transparent" />
          
          <div className="bg-slate-900/50 px-4 py-2 border-b border-primary/10 flex items-center gap-2">
            <Terminal size={12} className="text-secondary" />
            <h3 className="font-mono text-[10px] uppercase font-bold text-slate-400">Live_System_Log</h3>
          </div>

          <div className="flex-1 p-4 font-mono text-[10px] leading-relaxed overflow-auto text-primary/80">
            {LOGS.map((log, i) => (
              <div key={i} className="mb-1 flex gap-2">
                <span className={
                  log.type === 'info' ? 'text-secondary' :
                  log.type === 'proc' ? 'text-primary' : 'text-error'
                }>
                  [{log.type.toUpperCase()}]
                </span>
                <span className="flex-1">
                  {log.content}
                  {log.active && <span className="w-1 h-3 bg-secondary animate-pulse inline-block ml-1 align-middle" />}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-auto border-t border-primary/10 p-2 bg-black/40">
            <div className="flex justify-between font-mono text-[9px] text-slate-500 px-2">
              <span>CPU: 42.1%</span>
              <span>MEM: 12.8GB</span>
              <span>DISK: 88%</span>
            </div>
          </div>
        </div>
      </section>

      {/* HUD Widget */}
      <div className="fixed bottom-10 right-10 pointer-events-none">
        <div className="glass-panel p-4 flex flex-col gap-2">
          <span className="font-mono text-[10px] text-primary/60 uppercase">System_Load</span>
          <div className="flex items-end gap-1 h-8">
            {[40, 60, 30, 80, 50, 90, 45, 70].map((h, i) => (
              <motion.div 
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ duration: 1, delay: i * 0.1, repeat: Infinity, repeatType: 'reverse' }}
                className="w-1 bg-secondary"
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
