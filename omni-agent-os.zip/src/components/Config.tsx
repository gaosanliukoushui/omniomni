import { Save, Terminal, History, Code, Cpu, Database, Info, SortAsc, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Config() {
  return (
    <div className="h-full flex flex-col p-8 gap-6 overflow-y-auto">
      {/* Header */}
      <div className="glass-panel rounded-lg flex flex-wrap justify-between items-center gap-3 p-4 border-b-2 border-b-primary/50">
        <div className="flex items-center gap-3">
          <Cpu size={32} className="text-primary glow-primary" />
          <h2 className="text-white tracking-widest text-2xl font-bold font-headline uppercase glow-text-primary">Agent Configuration</h2>
        </div>
        <button className="flex items-center justify-center rounded h-10 px-6 bg-primary/10 border border-primary text-primary hover:bg-primary hover:text-black hover:shadow-[0_0_15px_rgba(6,228,249,0.6)] transition-all duration-300 text-sm font-bold tracking-[0.1em] uppercase font-headline">
          <Save size={18} className="mr-2" />
          Save Configuration
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* System Prompt */}
        <div className="col-span-1 lg:col-span-8 flex flex-col gap-4">
          <h3 className="text-primary text-sm font-bold tracking-[0.1em] px-2 font-headline flex items-center gap-2 uppercase">
            <Terminal size={16} /> System Prompt
          </h3>
          <div className="glass-panel rounded-lg flex flex-col min-h-[600px] overflow-hidden border-t-2 border-t-primary/50 relative">
            <div className="flex items-center justify-between px-4 py-3 border-b border-primary/20 bg-black/40">
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                  <div className="w-2.5 h-2.5 rounded-full bg-secondary/50" />
                </div>
                <div className="h-4 w-[1px] bg-slate-700" />
                <span className="font-mono text-[11px] text-primary/70 tracking-wider">root/config/core_persona.sys</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500">
                <History size={16} className="hover:text-primary cursor-pointer" />
                <Code size={16} className="hover:text-primary cursor-pointer" />
              </div>
            </div>
            <div className="p-6 font-mono text-[13px] leading-relaxed text-slate-300 overflow-y-auto h-full bg-black/50 outline-none" contentEditable suppressContentEditableWarning spellCheck="false">
              <span className="text-slate-500"># CORE IDENTITY DEFINITION</span><br/>
              <span className="text-purple font-semibold">ROLE:</span> You are an expert-level technical analyst operating within the Omni-Agent-OS RAG terminal.<br/>
              <span className="text-purple font-semibold">OBJECTIVE:</span> Synthesize retrieved knowledge into precise, zero-fluff, technically accurate responses.<br/><br/>
              <span className="text-slate-500"># BEHAVIORAL CONSTRAINTS</span><br/>
              <span className="text-primary">-</span> Rely <span className="text-secondary italic">exclusively</span> on the provided context. Do not hallucinate external facts.<br/>
              <span className="text-primary">-</span> If context is insufficient, abort generation and output: <span className="text-red-400 bg-red-400/10 px-1 rounded">ERR_INSUFFICIENT_DATA</span>.<br/>
              <span className="text-primary">-</span> Format all structured data as valid JSON or markdown tables.<br/>
              <span className="text-primary">-</span> Always append citations using the exact <span className="text-yellow-400">{"{doc_id}"}</span> reference.<br/><br/>
              <span className="text-slate-500"># PIPELINE INJECTION POINTS</span><br/>
              <div className="pl-4 border-l-2 border-primary/30 my-2">
                <span className="text-slate-500">&lt;!-- DYNAMIC CONTEXT BLOCK --&gt;</span><br/>
                <span className="text-primary">&lt;context&gt;</span><br/>
                <span className="text-yellow-400 font-bold bg-yellow-400/10 px-1 rounded">{"{retrieved_chunks_formatted}"}</span><br/>
                <span className="text-primary">&lt;/context&gt;</span>
              </div><br/>
              <div className="pl-4 border-l-2 border-secondary/30 my-2">
                <span className="text-slate-500">&lt;!-- USER INTENT --&gt;</span><br/>
                <span className="text-secondary">&lt;query&gt;</span><br/>
                <span className="text-yellow-400 font-bold bg-yellow-400/10 px-1 rounded">{"{sanitized_user_input}"}</span><br/>
                <span className="text-secondary">&lt;/query&gt;</span>
              </div><br/>
              <span className="text-slate-500"># EXECUTE</span><br/>
              <span className="text-purple font-semibold">BEGIN_GENERATION:</span>
            </div>
          </div>
        </div>

        {/* Parameters */}
        <div className="col-span-1 lg:col-span-4 flex flex-col gap-6">
          <div className="flex flex-col gap-4">
            <h3 className="text-primary text-sm font-bold tracking-[0.1em] px-2 font-headline flex items-center gap-2 uppercase">
              <Cpu size={16} /> LLM Parameters
            </h3>
            <div className="glass-panel rounded-lg p-5 flex flex-col gap-5">
              <div className="flex flex-col gap-2">
                <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest">Active Model Engine</label>
                <select className="w-full bg-black border border-primary/30 text-white text-sm font-mono rounded px-3 py-2.5 focus:outline-none focus:border-primary">
                  <option>Claude 3 Opus [200k ctx]</option>
                  <option>GPT-4 Turbo [128k ctx]</option>
                  <option>Mixtral 8x7B [32k ctx]</option>
                </select>
              </div>
              
              <div className="flex flex-col gap-3">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest flex items-center gap-1">
                    Temperature <Info size={12} />
                  </label>
                  <span className="text-purple font-mono text-xs font-bold bg-purple/10 px-2 py-0.5 rounded border border-purple/30">0.85</span>
                </div>
                <input type="range" className="w-full accent-purple h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" defaultValue="85" />
                <div className="flex justify-between text-[10px] font-mono text-slate-600">
                  <span>Deterministic</span>
                  <span>Creative</span>
                </div>
              </div>

              <div className="flex flex-col gap-3 pt-2 border-t border-white/5">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest">Max Output Tokens</label>
                  <span className="text-primary font-mono text-xs font-bold bg-primary/10 px-2 py-0.5 rounded border border-primary/30">2048</span>
                </div>
                <input type="range" className="w-full accent-primary h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" defaultValue="50" />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-primary text-sm font-bold tracking-[0.1em] px-2 font-headline flex items-center gap-2 uppercase">
              <Database size={16} /> Vector Retrieval
            </h3>
            <div className="glass-panel rounded-lg p-5 flex flex-col gap-5">
              <div className="flex flex-col gap-3">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest">Top-K Chunks</label>
                  <span className="text-primary font-mono text-xs font-bold bg-primary/10 px-2 py-0.5 rounded border border-primary/30">12</span>
                </div>
                <input type="range" className="w-full accent-primary h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" defaultValue="24" />
              </div>

              <div className="flex flex-col gap-3 pt-2 border-t border-white/5">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest">Similarity Threshold</label>
                  <span className="text-secondary font-mono text-xs font-bold bg-secondary/10 px-2 py-0.5 rounded border border-secondary/30">0.78</span>
                </div>
                <input type="range" className="w-full accent-secondary h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" defaultValue="78" />
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-white/5">
                <label className="text-[11px] font-mono text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <SortAsc size={14} className="text-primary" /> Enable Reranking
                </label>
                <div className="w-10 h-5 bg-primary/20 rounded-full relative cursor-pointer border border-primary/50">
                  <div className="absolute right-1 top-1 w-3 h-3 bg-primary rounded-full shadow-[0_0_8px_#00E5FF]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
