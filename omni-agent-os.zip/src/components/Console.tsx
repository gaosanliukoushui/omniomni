import { Search, Filter, MessageSquare, Send, Paperclip, History, Database, Info } from 'lucide-react';
import { KnowledgeItem, Message } from '../types';
import { motion } from 'motion/react';

const KNOWLEDGE_ITEMS: KnowledgeItem[] = [
  { id: '1', name: 'DOC_8829_QA.pdf', chunks: 1242, simIdx: 0.94, status: 'active' },
  { id: '2', name: 'SYSTEM_SPECS_V4.md', chunks: 412, simIdx: 0.88, status: 'active' },
  { id: '3', name: 'USER_GUIDE_EN.txt', chunks: 89, simIdx: 0.99, status: 'active' },
  { id: '4', name: 'NEW_UPLOAD_441.csv', chunks: 0, simIdx: 0, status: 'processing' },
];

const MESSAGES: Message[] = [
  { id: '1', role: 'agent', content: 'Terminal initialized. Knowledge base sources verified (3 active). How can I assist with the system state analysis today?', timestamp: '14:02:11' },
  { id: '2', role: 'user', content: 'Analyze the discrepancy between DOC_8829 and SYSTEM_SPECS regarding core cooling parameters.', timestamp: '14:02:45' },
  { id: '3', role: 'agent', content: 'I found a direct conflict in the cooling thresholds. According to DOC_8829_QA.pdf, the nominal range is 20°C - 45°C. However, SYSTEM_SPECS_V4.md specifies a stricter operational envelope of 22°C - 38°C.\n\nThis discrepancy (Δ7°C) could trigger false positive alarms in the secondary circuit. Should I update the policy state?', timestamp: '14:02:48' },
];

export default function Console() {
  return (
    <div className="h-full grid grid-cols-10 gap-px bg-primary/10">
      {/* Knowledge Index */}
      <section className="col-span-2 flex flex-col bg-background border-r border-primary/10">
        <div className="p-4 border-b border-primary/10 flex justify-between items-center bg-black/20">
          <h3 className="font-headline text-xs font-bold tracking-widest text-primary uppercase">Knowledge Index</h3>
          <Filter size={14} className="text-primary/50" />
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          {KNOWLEDGE_ITEMS.map((item) => (
            <div 
              key={item.id}
              className={`p-3 transition-colors cursor-pointer group border ${
                item.status === 'processing' 
                  ? 'bg-primary/5 border-dashed border-primary/20 opacity-60' 
                  : 'bg-slate-900/50 border-transparent hover:bg-primary/5 hover:border-primary/20'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`font-mono text-[10px] ${item.status === 'processing' ? 'text-slate-500' : 'text-slate-300 group-hover:text-primary'}`}>
                  {item.name}
                </span>
                {item.status === 'active' && (
                  <div className="w-1.5 h-1.5 rounded-full bg-secondary shadow-[0_0_5px_#00ffa3]" />
                )}
                {item.status === 'processing' && (
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  >
                    <History size={10} className="text-primary" />
                  </motion.div>
                )}
              </div>
              <div className="flex items-center gap-3 font-mono text-[9px] text-slate-500">
                <span>CHUNKS: {item.chunks.toLocaleString()}</span>
                {item.simIdx > 0 && <span>SIM_IDX: {item.simIdx}</span>}
              </div>
              {item.status === 'processing' && (
                <div className="w-full bg-slate-800 h-0.5 mt-2 overflow-hidden">
                  <motion.div 
                    initial={{ x: '-100%' }}
                    animate={{ x: '0%' }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="bg-primary w-2/3 h-full" 
                  />
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="p-4 bg-black/40 border-t border-primary/10">
          <button className="w-full py-2 border border-primary/30 text-primary font-mono text-[10px] flex items-center justify-center gap-2 hover:bg-primary/10 transition-all uppercase">
            <Search size={12} /> INDEX_NEW_SOURCE
          </button>
        </div>
      </section>

      {/* Terminal Chat */}
      <section className="col-span-5 flex flex-col bg-background relative">
        <div className="h-12 border-b border-primary/10 flex items-center px-6 justify-between bg-black/20">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-secondary rounded-full shadow-[0_0_5px_#00ffa3]" />
            <span className="font-mono text-[10px] tracking-widest text-secondary uppercase">Agent_Active // RAG_Mode_Enabled</span>
          </div>
          <div className="flex items-center gap-4 font-mono text-[10px] text-slate-500">
            <span>TOKEN_COST: 0.0021</span>
            <span>TEMP: 0.7</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {MESSAGES.map((msg) => (
            <div 
              key={msg.id}
              className={`flex flex-col gap-2 max-w-[90%] ${msg.role === 'user' ? 'items-end ml-auto' : 'items-start'}`}
            >
              <div className={`flex items-center gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <span className={`font-mono text-[10px] px-2 py-0.5 ${msg.role === 'agent' ? 'text-primary bg-primary/10' : 'text-secondary bg-secondary/10'}`}>
                  {msg.role === 'agent' ? 'OMNI_AGENT' : 'ADMIN_USER'}
                </span>
                <span className="font-mono text-[8px] text-slate-500">{msg.timestamp}</span>
              </div>
              <div className={`p-4 text-sm leading-relaxed glass-panel border-l-2 ${
                msg.role === 'agent' 
                  ? 'border-l-primary' 
                  : 'border-l-secondary bg-slate-800/40'
              }`}>
                {msg.content.split('\n').map((line, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>{line}</p>
                ))}
                {msg.role === 'agent' && msg.id === '3' && (
                  <div className="mt-4 border-t border-primary/10 pt-3 flex items-center gap-2 font-mono text-[9px] text-slate-500">
                    <Search size={10} /> RAG_SEARCH_COMPLETE (2 hits found)
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 bg-black/40 border-t border-primary/10">
          <div className="relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <span className="font-mono text-primary group-focus-within:glow-text-primary">&gt;</span>
            </div>
            <input 
              className="w-full bg-slate-900/50 border-b border-primary/30 text-slate-200 font-mono text-sm pl-10 pr-12 py-4 focus:ring-0 focus:border-primary transition-all placeholder:text-slate-600"
              placeholder="TYPE_COMMAND_OR_QUERY_HERE..."
              type="text"
            />
            <div className="absolute inset-y-0 right-4 flex items-center">
              <button className="text-primary hover:text-secondary transition-colors">
                <Send size={18} />
              </button>
            </div>
          </div>
          <div className="mt-3 flex gap-4">
            <button className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/50 border border-primary/10 hover:bg-primary/10 transition-colors">
              <Paperclip size={10} className="text-slate-500" />
              <span className="font-mono text-[9px] text-slate-500 uppercase">Upload_Context</span>
            </button>
            <button className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/50 border border-primary/10 hover:bg-primary/10 transition-colors">
              <History size={10} className="text-slate-500" />
              <span className="font-mono text-[9px] text-slate-500 uppercase">Clear_History</span>
            </button>
          </div>
        </div>
      </section>

      {/* Trace & State */}
      <section className="col-span-3 flex flex-col bg-background border-l border-primary/10 overflow-hidden">
        <div className="h-1/2 flex flex-col border-b border-primary/10">
          <div className="p-4 bg-black/20 flex justify-between items-center">
            <h3 className="font-headline text-xs font-bold tracking-widest text-primary uppercase">State Machine Tracker</h3>
            <span className="font-mono text-[9px] text-secondary uppercase">Real_Time_Flow</span>
          </div>
          <div className="flex-1 flex items-center justify-center p-6 bg-black/40 relative overflow-hidden">
            <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #00E5FF 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
            <svg viewBox="0 0 400 300" className="w-full h-full drop-shadow-2xl">
              <path d="M 50 150 L 150 70 L 250 150 L 150 230 Z" fill="none" stroke="rgba(0, 229, 255, 0.1)" strokeWidth="1" />
              <path d="M 50 150 L 150 70" fill="none" stroke="rgba(0, 229, 255, 0.4)" strokeWidth="2" className="animate-flow" />
              <path d="M 150 70 L 250 150" fill="none" stroke="rgba(0, 255, 163, 0.4)" strokeWidth="2" className="animate-flow" style={{ animationDelay: '0.5s' }} />
              
              <g transform="translate(50, 150)">
                <rect x="-15" y="-15" width="30" height="30" className="fill-slate-900 stroke-primary/50" />
                <text y="30" textAnchor="middle" className="fill-primary font-mono text-[10px]">INGEST</text>
                <circle r="3" className="fill-secondary shadow-glow-primary" />
              </g>
              <g transform="translate(150, 70)">
                <rect x="-15" y="-15" width="30" height="30" className="fill-slate-900 stroke-primary/50" />
                <text y="-25" textAnchor="middle" className="fill-primary font-mono text-[10px]">EMBED</text>
                <circle r="3" className="fill-secondary shadow-glow-primary" />
              </g>
              <g transform="translate(250, 150)">
                <rect x="-15" y="-15" width="30" height="30" className="fill-primary stroke-primary" />
                <text y="30" textAnchor="middle" className="fill-primary font-mono text-[10px] font-bold">RETRIEVE</text>
                <circle r="4" className="fill-white" />
              </g>
              <g transform="translate(150, 230)">
                <rect x="-15" y="-15" width="30" height="30" className="fill-slate-900 stroke-primary/50" />
                <text y="30" textAnchor="middle" className="fill-primary font-mono text-[10px]">SYNTHESIZE</text>
              </g>
            </svg>
          </div>
        </div>

        <div className="h-1/2 flex flex-col">
          <div className="p-4 bg-black/20 flex justify-between items-center border-b border-primary/10">
            <h3 className="font-headline text-xs font-bold tracking-widest text-primary uppercase">Source Citations</h3>
            <span className="font-mono text-[9px] text-slate-500 uppercase">Matched: 02</span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="glass-panel p-3 border-l-2 border-l-secondary">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <Database size={12} className="text-secondary" />
                  <span className="font-mono text-[10px] text-slate-200">DOC_8829_QA.pdf</span>
                </div>
                <span className="font-mono text-[10px] bg-secondary/20 text-secondary px-1.5">SCORE: 0.94</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400 font-mono mb-2 italic">
                "...nominal operating temperatures for the core capacitor array must maintain a stable range between 20C and 45C to ensure longevity..."
              </p>
              <div className="flex justify-between items-center">
                <span className="text-[8px] font-mono text-slate-500">CHUNK_ID: 044-A</span>
                <button className="text-[9px] font-mono text-primary hover:underline uppercase">Open_Full_Source</button>
              </div>
            </div>

            <div className="glass-panel p-3 border-l-2 border-l-primary/50">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <Database size={12} className="text-primary" />
                  <span className="font-mono text-[10px] text-slate-200">SYSTEM_SPECS_V4.md</span>
                </div>
                <span className="font-mono text-[10px] bg-primary/20 text-primary px-1.5">SCORE: 0.89</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400 font-mono mb-2 italic">
                "...Hard-limit threshold established at 38C for emergency venting. Operations exceeding this value without override will..."
              </p>
              <div className="flex justify-between items-center">
                <span className="text-[8px] font-mono text-slate-500">CHUNK_ID: 112-C</span>
                <button className="text-[9px] font-mono text-primary hover:underline uppercase">Open_Full_Source</button>
              </div>
            </div>

            <div className="mt-4 p-4 border border-primary/20 bg-black/40 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full border-2 border-primary/20 flex items-center justify-center relative">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-0 rounded-full border-2 border-primary border-t-transparent"
                />
                <span className="font-mono text-[10px] text-primary">82%</span>
              </div>
              <div>
                <p className="font-headline text-[10px] font-bold text-primary uppercase">Contextual Density</p>
                <p className="font-mono text-[8px] text-slate-500">Optimal retrieval parameters active</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
