import { useState } from 'react';
import Layout from './components/Layout';
import Console from './components/Console';
import Ingestion from './components/Ingestion';
import StateTracker from './components/StateTracker';
import Config from './components/Config';
import { Page } from './types';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('console');

  return (
    <Layout currentPage={currentPage} onPageChange={setCurrentPage}>
      {currentPage === 'console' && <Console />}
      {currentPage === 'ingestion' && <Ingestion />}
      {currentPage === 'tracker' && <StateTracker />}
      {currentPage === 'config' && <Config />}
    </Layout>
  );
}
