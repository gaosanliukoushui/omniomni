export type Page = 'console' | 'ingestion' | 'tracker' | 'config';

export interface Message {
  id: string;
  role: 'agent' | 'user';
  content: string;
  timestamp: string;
  tokens?: number;
}

export interface KnowledgeItem {
  id: string;
  name: string;
  chunks: number;
  simIdx: number;
  status: 'active' | 'processing' | 'pending';
}

export interface PipelineItem {
  id: string;
  name: string;
  chunks: string;
  tokens: string;
  vectors: string;
  status: 'synced' | 'vectorizing' | 'queued' | 'error';
  progress: number;
}
